<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/index/login.html";i:1560306503;}*/ ?>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title>{#pageTitle#}</title>
    <link rel="stylesheet" href="__STATIC__/css/pintuer.css">
    <link rel="stylesheet" href="__STATIC__/css/admin.css">
    <script src="__STATIC__/js/jquery.js"></script>
    <script src="__STATIC__/js/pintuer.js"></script>
    <script type="text/javascript">
        var arr;
        function yan(){
            arr='';
            var chang=4;
            var suiji=[0,1,2,3,4,5,6,7,8,9,'a','b','c','d','e','f','g','h','i','j','k',
                'l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
            for(i=0;i<chang;i++)
            {
                var dedao=Math.floor(Math.random()*36);
                arr+=suiji[dedao];
            }
            document.getElementById("yanzheng").innerHTML=arr;
        }
        function ca(){
            var ma=fom.ma.value;
            var zongma=arr;
            if(ma!=zongma)
            {
                alert("验证码错误");
                yan();
                return false;
            }
        }
        window.onload = function (){

            yan();
        }
    </script>

</head>
<body>
<div class="bg"></div>
<div class="container">
    <div class="line bouncein">
        <div class="xs6 xm4 xs3-move xm4-move">
            <div style="height:150px;"></div>
            <div class="media media-y margin-big-bottom">
            </div>
            <form action="<?php echo url('admin/Index/Login'); ?>" method="post" name="fom">
                <div class="panel loginbox">
                    <div class="text-center margin-big padding-big-top"><h1>后台管理中心</h1></div>
                    <div class="panel-body" style="padding:30px; padding-bottom:10px; padding-top:10px;">
                        <div class="form-group">
                            <div class="field field-icon-right">
                                <input type="text" class="input input-big" name="name" placeholder="登录账号" data-validate="required:请填写账号" />
                                <span class="icon icon-user margin-small"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="field field-icon-right">
                                <input type="password" class="input input-big" name="pass" placeholder="登录密码" data-validate="required:请填写密码" />
                                <span class="icon icon-key margin-small"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="field">
                                <input type="text" class="input input-big" name="ma" placeholder="填写下侧的验证码" data-validate="required:请填写验证码" />
                            </div>
                        </div>
                        <div class="form-group">
                            <div>
                                <span name="ma" id="yanzheng" style="background-image:url(images/bg.jpg); width:120px; height:60px; display:block; font-size:40px; line-height:60px; color:#f00; margin-top:20px; padding-left:10px"></span><input type="button" value="换一换" name="huan"  onclick="return yan()" /></td>
                            </div>
                        </div>
                    </div>
                    <div style="padding:30px;"><input type="submit" name='submit' class="button button-block bg-main text-big input-big" value="登录" onclick="return ca()" /></div>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>