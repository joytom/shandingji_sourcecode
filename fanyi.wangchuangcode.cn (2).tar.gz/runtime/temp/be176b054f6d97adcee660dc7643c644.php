<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/index/add.html";i:1560479585;}*/ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <title>完整demo</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="renderer" content="webkit">
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/ueditor.config.js"></script>
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/ueditor.all.min.js"> </script>
  <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
  <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/lang/zh-cn/zh-cn.js"></script>

  <link rel="stylesheet" href="__STATIC__/css/pintuer.css">
  <link rel="stylesheet" href="__STATIC__/css/admin.css">
  <script src="__STATIC__/js/jquery.js"></script>
  <script src="__STATIC__/js/pintuer.js"></script>

  <style type="text/css">
    div{
      width:100%;
    }
  </style>
</head>
<body>
<form method="post" action="<?php echo url('admin/Index/add'); ?>">
  
  <div class="form-group" style="margin-bottom: 50px">
    <div class="label">
      <label> <h3>标题：</h3> </label>
    </div>
    <div class="field">
      <input type="text" class="input w50"  name="title" name="tiele"  data-validate="required:请输入标题" />
      <div class="tips"></div>
    </div>
  </div>
  <div class="form-group" style="margin-bottom: 55px">
    <div class="label">
      <label>选择文章分类：</label>
    </div>
    <div class="field">

      <select name="tid" class="input w50">
        <option>--请选择文章类型--</option>
        <?php if(is_array($type) || $type instanceof \think\Collection || $type instanceof \think\Paginator): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$loop): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $loop['tid']; ?>"><?php echo $loop['tname']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
      <!--<div class="tips"> <button class="button bg-blue margin-left" id="image1" style="float:left;"><a href="<?php echo url('admin/Index/addType'); ?>">新加文章类型</a></button></div>-->
    </div>
  </div>



  <div>

    <textarea id="editor" name="ue" type="text/plain" style="width:1024px;height:500px;"></textarea>
  </div>
  <div class="tips">  <input class="button bg-blue margin-left" id="image1" style="float:left;" type="submit" name="sub" value="提交" /></div>


</form>

  <script type="text/javascript">
      var ue = UE.getEditor('editor');
  </script>
</body>
</html>