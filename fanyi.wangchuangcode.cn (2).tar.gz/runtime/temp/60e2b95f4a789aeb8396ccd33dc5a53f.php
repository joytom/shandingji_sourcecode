<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/index/update.html";i:1560410164;}*/ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
        "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <title>完整demo</title>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <meta name="renderer" content="webkit">
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/ueditor.config.js"></script>
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/ueditor.all.min.js"> </script>
  <!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
  <!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
  <script type="text/javascript" charset="utf-8" src="__STATIC__/utf8-php/lang/zh-cn/zh-cn.js"></script>

  <link rel="stylesheet" href="__STATIC__/css/pintuer.css">
  <link rel="stylesheet" href="__STATIC__/css/admin.css">
  <script src="__STATIC__/js/jquery.js"></script>
  <script src="__STATIC__/js/pintuer.js"></script>

  <style type="text/css">
    div{
      width:100%;
    }
  </style>
</head>
<body>
<div class="panel admin-panel margin-top" id="add">
  <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 修改内容</strong></div>
  <div class="body-content">
    <form method="post" class="form-x" action="<?php echo url('admin/Index/update'); ?>">
      <input type="hidden" value="<?php echo $arr['id']; ?>" name="id" />
      <div class="form-group" style="margin-bottom: 22px">
        <div class="label">
          <label>选择文章分类：</label>
        </div>
        <div class="field">

          <select name="tid" class="input w50">
            <option>--请选择文章类型--</option>
            <?php if(is_array($type) || $type instanceof \think\Collection || $type instanceof \think\Paginator): $i = 0; $__LIST__ = $type;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$loop): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $loop['tid']; ?>" <?php if($arr['tid']==$loop['tid']): ?> selected="selected"<?php endif; ?>><?php echo $loop['tname']; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
          </select>
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>标题：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" value="<?php echo $arr['title']; ?>" name="title" data-validate="required:请输入标题" />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label>描述：</label>
        </div>
        <div>
          <textarea id="editor" name="ue" type="text/plain" style="width:1024px;height:500px;"><?php echo $arr['content']; ?></textarea>
        </div>
         <script type="text/javascript">
              var ue = UE.getEditor('editor');
         </script>
      </div>
      <div class="form-group">
        <div class="label">
          <label>时间：</label>
        </div>
        <div class="field">
          <input type="text" class="input w50" name="sort" value="<?php echo $arr['adate']; ?>" readonly />
          <div class="tips"></div>
        </div>
      </div>
      <div class="form-group">
        <div class="label">
          <label></label>
        </div>
        <div class="field">
          <input class="bg-main icon-check-square-o" type="submit" value="提交" name="sub" />
        </div>
      </div>
    </form>
  </div>
</div>
</body></html>