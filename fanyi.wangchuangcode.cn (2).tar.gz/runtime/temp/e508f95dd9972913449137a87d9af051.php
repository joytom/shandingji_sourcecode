<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:88:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/index/addType.html";i:1560481526;s:84:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/comm/head.html";i:1560254922;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>
    <link rel="stylesheet" href="__STATIC__/css/pintuer.css">
    <link rel="stylesheet" href="__STATIC__/css/admin.css">
    <script src="__STATIC__/js/jquery.js"></script>
    <script src="__STATIC__/js/pintuer.js"></script>



</head>
<body>
<form method="post" action="<?php echo url('admin/Index/addType'); ?>">

    <div class="form-group" style="margin-bottom: 50px">
        <div class="label">
            <label> <h3>类型：</h3> </label>
        </div>
        <div class="field">
            <input type="text" class="input w50"  name="type" name="type"  data-validate="required:请输添加章类型" />
            <div class="tips"></div>
        </div>
    </div>
    <input type="submit" class="button bg-blue margin-left" style="float:left;" name="sub" value="提交" />

</form>
</body>
</html>