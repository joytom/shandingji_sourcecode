<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:92:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/index/ArticleList.html";i:1560496070;s:90:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/comm/navigation.html";i:1560493408;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>首页</title>
    <link rel="stylesheet" href="__STATIC__/qiantai/css/reset.css">
    <link rel="stylesheet" href="__STATIC__/qiantai/css/ArticleList.css">
    <script src="__STATIC__/qiantai/js/hotcss.js"></script>
    <script src="__STATIC__/qiantai/js/jquery-3.3.1.min.js"></script>
    <script src="__STATIC__/qiantai/js/common.js"></script>
</head>
<body>
<div class="container">
    <header>
        <div class="left">
            <a href="<?php echo url('index/index'); ?>" style="text-decoration: none"><h1>善顶级胶囊</h1></a>

            <p>www.shandingji.com</p>
        </div>
        <div class="right">
            <p></p>
            <p></p>
            <p></p>
        </div>
        <div class="close" style="display: none">
            <p></p>
            <p></p>
        </div>
    </header>
    <div class="option">
    <a href="<?php echo url('index/index'); ?>">首页</a>
    <a href="<?php echo url('index/ArticleList'); ?>?hid=最新文章">文章列表</a>
    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">在线订购</a>
</div>

    <main>
        <div class="search">
            <input type="text" id="serach" placeholder="请输入搜索内容">
            <input type="hidden" id="tid" value="<?php echo $tid; ?>">
            <a id="sousuo">搜索</a>
        </div>
        <div class="box">
            <?php foreach($data_con as $con): ?>
            <a href="<?php echo url('index/index/ArticleDetail'); ?>?id=<?php echo $con['id']; ?>"  class="list">
<!--                <img src="" class="left" alt="">-->
                <div class="right" style="padding-left: 25px;">
                    <h1><?php echo $con['titles']; ?></h1>
                    <h4><?php echo $con['contents']; ?></h4>
                    <p class="time">发布时间：<?php echo $con['adate']; ?></p>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </main>
</div>
</body>
<script>
    $("#sousuo").click(function () {
        var serach = $("#serach").val();
        var tid = $("#tid").val();
        $.post("<?php echo url('index/ArticleSearch'); ?>",{serach:serach,tid:tid},function(data){
            $(".box").html(data);
        });
    })
</script>
</html>