<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:92:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/index/type_update.html";i:1560478143;s:84:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/admin/view/comm/head.html";i:1560254922;}*/ ?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="renderer" content="webkit">
    <title></title>
    <link rel="stylesheet" href="__STATIC__/css/pintuer.css">
    <link rel="stylesheet" href="__STATIC__/css/admin.css">
    <script src="__STATIC__/js/jquery.js"></script>
    <script src="__STATIC__/js/pintuer.js"></script>



</head>
<body>
<div class="panel admin-panel margin-top" id="add">
    <div class="panel-head"><strong><span class="icon-pencil-square-o"></span> 修改内容</strong></div>
    <div class="body-content">
        <form method="post" class="form-x" action="<?php echo url('admin/Index/type_update'); ?>">
            <input type="hidden" value="<?php echo $arr['tid']; ?>" name="tid" />

            <div class="form-group">
                <div class="label">
                    <label>文章类型：</label>
                </div>
                <div class="field">
                    <input type="text" class="input w50" value="<?php echo $arr['tname']; ?>" name="tname" data-validate="required:更改文章类型" />
                    <div class="tips"></div>
                </div>
            </div>
            <div class="form-group">
                <div class="label">
                    <label></label>
                </div>
                <div class="field">
                    <input class="bg-main icon-check-square-o" type="submit" value="提交" name="sub" />
                </div>
            </div>
        </form>
    </div>
</div>
</body></html>