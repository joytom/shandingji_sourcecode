<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:90:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/index/OnlionBuy.html";i:1560474400;s:90:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/comm/navigation.html";i:1560493408;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>在线订购</title>
    <link rel="stylesheet" href="__STATIC__/qiantai/css/reset.css">
    <link rel="stylesheet" href="__STATIC__/qiantai/css/OnlionBuy.css">
    <script src="__STATIC__/qiantai/js/hotcss.js"></script>
    <script src="__STATIC__/qiantai/js/jquery-3.3.1.min.js"></script>
    <script src="__STATIC__/qiantai/js/common.js"></script>
</head>
<body>
<div class="container">
    <header>
        <div class="left">
            <a href="<?php echo url('index/index'); ?>" style="text-decoration: none"><h1>善顶级胶囊</h1></a>

            <p>www.shandingji.com</p>
        </div>
        <div class="right">
            <p></p>
            <p></p>
            <p></p>
        </div>
        <div class="close" style="display: none">
            <p></p>
            <p></p>
        </div>
    </header>
    <div class="option">
    <a href="<?php echo url('index/index'); ?>">首页</a>
    <a href="<?php echo url('index/ArticleList'); ?>?hid=最新文章">文章列表</a>
    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">在线订购</a>
</div>

    <main>
        <p class="linear"></p>
        <div class="box">
            <div class="list">
                <p>产品名称：</p>
                <select name="" id="">
                    <option value="">请选择产品</option>
                    <option value="">善顶级</option>
                </select>
            </div>
            <div class="list">
                <p>真实姓名：</p>
                <input type="text" placeholder="请输入收货人姓名">
            </div>
            <div class="list">
                <p>身份证号：</p>
                <input type="text" placeholder="请输入身份证号">
            </div>
            <div class="list">
                <p>手机号：</p>
                <input type="text" placeholder="请输入手机号">
            </div>
            <div class="list">
                <p>配送区域：</p>
                <div class="lists">
                    <select name="" id="">
                        <option value="">选择省</option>
                        <option value="">广东省</option>
                    </select>
                    <select name="" id="">
                        <option value="">选择省</option>
                        <option value="">广东省</option>
                    </select>
                    <select name="" id="">
                        <option value="">选择省</option>
                        <option value="">广东省</option>
                    </select>
                </div>
            </div>
            <div class="Remarks">
                <p class="title">备注</p>
                <textarea name="" placeholder="请输入备注内容" id=""></textarea>
                <p class="num">0/1000</p>
            </div>
            <a href="#" class="apply">确认提交</a>
        </div>
    </main>
</div>
</body>
</html>