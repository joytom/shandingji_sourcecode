<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:86:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/index/index.html";i:1560495622;s:90:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/comm/navigation.html";i:1560493408;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>首页</title>
    <link rel="stylesheet" href="__STATIC__/qiantai/css/reset.css">
    <link rel="stylesheet" href="__STATIC__/qiantai/css/index.css">
    <script src="__STATIC__/qiantai/js/hotcss.js"></script>
    <script src="__STATIC__/qiantai/js/jquery-3.3.1.min.js"></script>
    <script src="__STATIC__/qiantai/js/common.js"></script>
</head>
<body>
<div class="container">
    <header>
        <div class="left">
            <a href="<?php echo url('index/index'); ?>" style="text-decoration: none"><h1>善顶级胶囊</h1></a>
            <p>www.shandingji.com</p>
        </div>
        <div class="right">
            <p></p>
            <p></p>
            <p></p>
        </div>
        <div class="close" style="display: none">
            <p></p>
            <p></p>
        </div>
    </header>
<div class="option">
    <a href="<?php echo url('index/index'); ?>">首页</a>
    <a href="<?php echo url('index/ArticleList'); ?>?hid=最新文章">文章列表</a>
    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">在线订购</a>
</div>
    <main>
        <div class="item1">
            <img src="__STATIC__/qiantai/img/index2.png" class="left" alt="">
            <div class="right">
                <div class="box">
                    <h2>国外原装进口善顶级胶囊</h2>
                    <h1>营养腹壁  消解疝气</h1>
                    <ul>
                        <li>美国PCK科技研发</li>
                        <li>增强腹壁支持力</li>
                        <li>增强腹壁支持力</li>
                        <li>高活性好吸收</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="item2">
            <div class="box">
                <img src="__STATIC__/qiantai/img/index3.png" alt="">
                <div class="right">
                    <h2>疝气除了手术</h2>
                    <h1>还有其他选择吗</h1>
                    <p class="line"></p>
                    <div class="text">
                        <p>"面临疝气困扰，一部分人选择手术，但是手术在修补薄弱腹壁时，周围正常的腹壁组织因手术创伤影响，也会受到损害，手术后遇到腹内压增加，疝气会再次出现。</p>
                        <p>美国PCK科技位于德克萨斯州，是美国一家综合性的科研单位，PCK科技擅长汲取国际范围内的研发经验，进行综合整合，成功研发出多款产品。</p>
                        <p>善顶级（www.shandingji.com）由美国PCK科技研发，选取多种天然植物种子成分，进行特殊的提取过程，多种成分配比，协同作用，起到加强腹壁弹性和支持的作用。2016年我国也引进了善顶级（www.shandingji.com），进入国内后反馈不错。</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="item3">
            <div class="box">
                <h1> 疝气是什么?</h1>
                <img src="__STATIC__/qiantai/img/index4.png" alt="">
                <p>疝气，即人体内某个脏器或组织离开其正常解剖位置，通过先天或后天形成的薄弱点、缺损或孔隙进入另一部位。较常见的疝气是腹股沟疝气和脐疝，在腹股沟区或脐部看到或摸到鼓包，有些则会达到阴囊或阴唇，平卧后鼓包可以回纳至腹腔。</p>
            </div>
        </div>
        <div class="item4">
            <h1><span>疝气拖延</span>危害大</h1>
            <div class="box">
                <div class="smallBox">
                    <p>有些疝气人群还会出现腹部胀痛等其他问题，小儿疝气则可能出现会出现便秘、食欲不振等现象，长期拖延危害较大：</p>
                    <img src="__STATIC__/qiantai/img/index5.png" class="Exhibition" alt="">
                    <div class="img">
                        <img src="__STATIC__/qiantai/img/index6.png" alt="">
                        <img src="__STATIC__/qiantai/img/index7.png" alt="">
                        <img src="__STATIC__/qiantai/img/index8.png" alt="">
                    </div>
                </div>
                <div class="list">
                    <div class="lists">
                        <h2>影响消化系统</h2>
                        <p>疝气人群出现下腹部坠胀、腹胀气、腹痛、便秘、营养吸收功能差、易疲劳和体质下降等问题。</p>
                    </div>
                    <div class="lists">
                        <h2>心理饱受痛苦折磨</h2>
                        <p>疝气给疝气人群工作生活造成不便，会加大心理压力大，容易使疝气人群产生抑郁和自卑心理。</p>
                    </div>
                    <div class="lists">
                        <h2>影响发育和生育</h2>
                        <p>由于腹股沟部疝气与泌尿生殖系统相邻，所以老年疝气人群易出现尿频、尿急、夜尿增多等膀胱或前列腺问题；小孩则可因疝气的挤压而影响睾丸的正常发育；而中青年疝气人群则易导致性功能障碍，女性易导致不孕不育。</p>
                    </div>
                    <div class="lists">
                        <h2>危及生命健康</h2>
                        <p>疝囊内的肠管或网膜易受到挤压或碰撞引起炎性肿胀，致使疝气回纳困难，可能导致疝气嵌顿，以及肠梗阻、肠坏死、腹部剧痛等危险的发生，对疝气人群生命造成威胁，容易发生危险情况。</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="item5">
            <h1><span>腹壁薄弱</span>是形成疝气的主要原因</h1>
            <h2>——<span>The main reason for the formation of hernia</span>——</h2>
            <div class="box">
                <h3>疝气一般由两方面因素导致：（1）一方面是因为腹内压增高；（2）另一方面 是因为腹壁薄弱，腹壁弹力降低引起的。</h3>
                <div class="smallBox">
                    <img src="__STATIC__/qiantai/img/index10.png" class="left" alt="">
                    <p class="right">腹内压增高是外因，是引起疝气的表层因素（普通人在咳嗽或者提重物等情况下也会出现腹内压增高，但是不会出现疝气）；而腹壁变薄、腹壁弹性降低是引起疝气的主要原因，因为一般情况下，腹内压增高是无法避免的，如哭泣、咳嗽、便秘、用力排尿、提重物等情况下都有可能引起腹内压增高。所以，疝气需要修复腹壁，增强腹壁厚度与弹性。</p>
                </div>
            </div>
        </div>
        <div class="item6">
            <div class="top">
                <h1>国外进口善顶级  营养消疝</h1>
                <ul class="effect">
                    <li>降低过高腹内压</li>
                    <li>增强腹壁弹性</li>
                    <li>提高腹壁支持力</li>
                </ul>
                <img src="__STATIC__/qiantai/img/index13.png" alt="">
            </div>
            <div class="box">
                <div class="list">
                    <h2>降低腹压 复位疝囊</h2>
                    <p>善顶级进入人体血液循环，在荔枝种子与川楝子成分同时作用下行气活血，软化疝囊；在山楂等成分作用下，降低过高的腹内压，使凸起、偏坠的疝囊收缩回纳。</p>
                </div>
                <div class="list">
                    <h2>闭合疝口 复位器官</h2>
                    <p>疝囊回收入腹腔后，善顶级中的茴香成分，可以增强肠蠕动，使小肠自然收缩回原来所在位置，防止腹腔内器官的错乱，并促使疝口闭合。</p>
                </div>
                <div class="list">
                    <h2>减缓腹部胀痛</h2>
                    <p>AS腹壁支持素中的荔枝核、川楝子、橘核等成分配比协同作用，具有行气散结的作用，对小肠气及小肠气引起的腹痛、腹胀有较好的作用。</p>
                </div>
                <div class="list">
                    <h2>增强腹壁弹性和支撑</h2>
                    <p>将十几种纯天然草本成分配比结合在一起，在协同作用下，腹壁（下腹部肌肉）对器官和组织的支撑增强，起到加强腹壁弹性和支持的作用。</p>
                </div>
            </div>
        </div>
        <div class="item7">
            <h1>专业国外进口善顶级 营养腹壁</h1>
            <h2>纯天然植物种子配方 安全放心</h2>
            <p class="detail">善顶级有十几种植物种子成分混合配比而成，四种主要成分是山楂核、茴香、柑橘种子和荔枝种子，其余还有川楝子、桃仁、延胡索、泽泻茎、乌药、马尾藻等。</p>
            <div class="box">
                <div class="center">
                    <img src="__STATIC__/qiantai/img/index19.png" alt="">
                </div>
                <div class="com one">
                    <h3>荔枝种子</h3>
                    <p class="details">荔枝核性温、味甘、微苦，具有疏肝理气、止痛、行气散结等作用。它是修复疝气的主要成分，多用于疝痛、睾丸肿痛、少腹刺痛、腹内包块等问题。</p>
                </div>
                <div class="com two">
                    <h3>川楝子</h3>
                    <p class="details">与荔枝种子结合，对小肠气及小肠气引起的腹痛、腹胀有较好的作用。（《得配本草》卷二-卷五）</p>
                </div>
                <div class="com three">
                    <h3>山楂核</h3>
                    <p class="details">山楂核味苦、性平，对消化不良、腹胀等问题作用明显，具有消食、散结，修复疝气和睾丸偏坠的作用。</p>
                </div>
                <div class="com four">
                    <h3>柑橘种子</h3>
                    <p class="details">具有理气、散结、止痛的作用，对小肠疝气和睾丸肿痛有重要作用。（《纲目》）</p>
                </div>
                <div class="com five">
                    <h3>茴香</h3>
                    <p class="details">茴香种子可以修复疝气，尤其是婴幼儿疝气和腹股沟疝气，增强肠蠕动，使小肠自然收缩回到原来的位置，修复疝气问题。</p>
                </div>
            </div>
        </div>
        <div class="item8">
            <h1>国外进口善顶级<span>优势分析</span></h1>
            <ul>
                <li>美国原瓶原装进口</li>
                <li>营养腹壁</li>
                <li>增强腹壁支持力</li>
            </ul>
            <div class="list">
                <div class="lists">
                    <img src="__STATIC__/qiantai/img/index21.png" alt="">
                    <h2>美国原装进口</h2>
                    <p>善顶级厂家位于德克萨斯州，有多项研发产品，善顶级是其中之一，从生产研发到运输，都经过严格检验。</p>
                </div>
                <div class="lists">
                    <img src="__STATIC__/qiantai/img/index22.png" alt="">
                    <h2>协同作用</h2>
                    <p>采用消疝种子配方，主要成分有山楂核、荔枝核、桃仁、柑橘种子等十几种，协同作用下，起到加强腹壁弹性和支持的作用。</p>
                </div>
                <div class="lists">
                    <img src="__STATIC__/qiantai/img/index23.png" alt="">
                    <h2>原料制胜</h2>
                    <p>精选高活性种子，通过干燥、研磨等特殊处理，综合作用，同步修复腹壁，增强腹壁弹性与支持。</p>
                </div>
                <div class="lists">
                    <img src="__STATIC__/qiantai/img/index24.png" alt="">
                    <h2>安全天然</h2>
                    <p>善顶级原料全部采用纯天然植物种子为原材，没有任何化学添加，对人体没有任何副作用，老人孩子也可放心使用。</p>
                </div>
            </div>
        </div>
        <div class="item9">
            <h1>疝气人群反馈国外进口善顶级作用</h1>
            <div class="bc">
                <img src="__STATIC__/qiantai/img/index25.png" alt="">
            </div>
            <div class="box">
                <div class="list">
                    <img src="__STATIC__/qiantai/img/index26.png" alt="">
                    <h2>54岁——刘先生</h2>
                    <p class="detail">今年54岁了，夏天的时候感到大腿根的地方有疼痛感，晚上摸着有一个鸡蛋大小的鼓包，检查才知道是腹股沟疝气。和家人商量后，决定通过AS腹壁支持素进行调理，刚开始使用了20天左右，疼痛感明显减轻了，不像之前动都不敢动，稍微一用力，疝囊就掉下来了，坚持调理了2个多月，疝囊很时间没有在掉下来，我坚持把剩下的AS腹壁支持素用完，现在在已经好了。</p>
                    <p class="linear"></p>
                    <h3>fifty-four years old   Mr. Liu</h3>
                    <p class="EnglishDetail">I'm 54 years old. Last summer I felt pain at the root of my thigh. At night, I feel a lump the size of an egg. The examination revealed inguinal hernia. After discussing with my family, I decided to conduct conditioning through Abdominal Support. I started using it for about 20 days,the pain was clearly relieved. I didn't dare move before, because with a little bit of effort the hernia sac fell off. After more than 2 months of continuous conditioning, the hernia sac did not fall down for a long time. I insist on using up the rest of Abdominal Support, now it is ready.</p>
                </div>
                <div class="list">
                    <img src="__STATIC__/qiantai/img/index27.png" alt="">
                    <h2>35岁——张先生</h2>
                    <p class="detail">因为平时工作应酬比较多，生活作息不太规律，腹部过于肥胖，结果年后发现腹股沟处有个核桃大小的鼓包，后来打听到美国的AS腹壁支持素反馈不错。因为工作比较忙，平时没有按时使用AS腹壁支持素，有时会出现间断，但是在这样的情况下，用了不到两个月的时间，坠胀感逐渐减轻，鼓包就没有再出现了，都过了5个月的时间，也没有再出现过。<p>
                    <p class="linear"></p>
                    <h3>thirty-five years old   Mr. Zhang</h3>
                    <p class="EnglishDetail">Because work and social work are more frequent, life and rest are less regular and abdomen is too fat. The result was a walnut-sized drum in the groin. Later, I got a good feedback from Abdominal Support in the United States. Due to the busy work, I don't use Abdominal Support on time at ordinary times and sometimes there will be a break. But in this case, in less than two months, the feeling of falling and swelling gradually diminished. And the drum did not appear again. It's been five months and it's never been seen again.</p>
                </div>
                <div class="list">
                    <img src="__STATIC__/qiantai/img/index28.png" alt="">
                    <h2>8岁，家长——王女士</h2>
                    <p class="detail">我们家孩子今年8岁了，去年出现了疝气，给孩子洗澡的时候，发现大腿根那里有个山楂大小的肿块，刚开始比较害怕，后来检查说是腹股沟疝气。给孩子使用了美国进口的AS腹壁支持素，没想到孩子用了2瓶，腹股沟疝气就好了，现在孩子上学，在学校里我也比较放心，因为跑跑跳跳，那个鼓包都没有再鼓出来过。<p>
                    <p class="linear"></p>
                    <h3> 8 years old  Ms. Wang's children</h3>
                    <p class="EnglishDetail">My child is 8 years old and had a hernia last year. When I bathed the child, I found a hawthorn sized lump in the root of my thigh. I was scared at first, and then I had a groin hernia. The child was given Abdominal Support imported from the United States. I didn't think that the child would be better with 2 bottles of inguinal hernia.</p>
                </div>
            </div>
        </div>
        <div class="item10">
            <h1>在线订购</h1>
            <div class="box">
                <div class="smallBox">
                    <div class="list">
                        <div class="lists">
                            <h2>儿童外敷装</h2>
                            <div class="content">
                                <img src="__STATIC__/qiantai/img/index30.png" alt="">
                                <p class="num">2瓶</p>
                                <p class="price">￥1600</p>
                            </div>
                        </div>
                    </div>
                    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">立即购买</a>
                </div>
                <div class="smallBox">
                    <div class="list">
                        <div class="lists">
                            <h2>成人调理装</h2>
                            <div class="content">
                                <img src="__STATIC__/qiantai/img/index30.png" alt="">
                                <p class="num">3瓶</p>
                                <p class="price">￥2100</p>
                            </div>
                        </div>
                    </div>
                    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">立即购买</a>
                </div>
                <div class="smallBox">
                    <div class="list">
                        <div class="lists">
                            <h2>成人巩固装</h2>
                            <div class="content">
                                <img src="__STATIC__/qiantai/img/index30.png" alt="">
                                <p class="num">6瓶</p>
                                <p class="price">￥3400</p>
                            </div>
                        </div>
                    </div>
                    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">立即购买</a>
                </div>
                <div class="smallBox">
                    <div class="list">
                        <div class="lists">
                            <h2>成人修复装</h2>
                            <div class="content">
                                <img src="__STATIC__/qiantai/img/index30.png" alt="">
                                <p class="num">9瓶</p>
                                <p class="price">￥4750</p>
                            </div>
                        </div>
                    </div>
                    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">立即购买</a>
                </div>
            </div>
        </div>
        <div class="item11">
            <div class="box">
                <h2>参考文献</h2>
                <div class="list">
                    <div class="lists">
                        <p>1.《疝气》百科名医网，2014-07-18，[引用日期2018-06-04]</p>
                        <p>http://www.baikemy.com/disease/view/7150</p>
                    </div>
                    <div class="lists">
                        <p>2.《小肠疝气》百度百科，词条标签：科学 、疾病，[引用日期2018-06-04]</p>
                        <p>https://baike.baidu.com/item/%E5%B0%8F%E8%82%A0%E7%96%9D%E6%B0%94/4696065?fr=aladdin</p>
                    </div>
                    <div class="lists">
                        <p>3.美国PCK科技，德克萨斯州，厂家相关资料引用</p>
                    </div>
                    <div class="lists">
                        <p>4.《“疝气良药”荔枝核》陆小鸿，[J]，广西林业，2017(2):20-21</p>
                    </div>
                    <div class="lists">
                        <p>5.《冯氏锦囊·药性》，冯楚瞻，清代，公元1644-1911年，参卷四十四</p>
                    </div>
                    <div class="lists">
                        <p>6.《用华鼠尾草根、地黄根和茴香种子等混合物治疗人疝气》佚名，[J]，现代药物与临床，2006(2)</p>
                    </div>
                    <div class="lists">
                        <p>7.《得配本草》，严洁、施雯、洪炜，清代，1761年，参卷二-卷五</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="item12">
            <ul>
                <?php if(is_array($data_type) || $data_type instanceof \think\Collection || $data_type instanceof \think\Paginator): if( count($data_type)==0 ) : echo "" ;else: foreach($data_type as $k=>$dt): if($k==0): ?>
                <li class="opt active"><?php echo $dt['tname']; ?></li>
                <?php else: ?>
                <li class="opt"><?php echo $dt['tname']; ?></li>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </ul>
            <div class="content" id="neirong">
                <?php if(is_array($data_con) || $data_con instanceof \think\Collection || $data_con instanceof \think\Paginator): if( count($data_con)==0 ) : echo "" ;else: foreach($data_con as $k=>$dc): if($k<3): ?>
                <a href="<?php echo url('index/index/ArticleDetail'); ?>?id=<?php echo $dc['id']; ?>" class="list">
<!--                    <img src="" class="left" alt="">-->
                    <div class="right">
                        <h1 class="hotTop"><span>置顶</span><?php echo $dc['title']; ?></h1>
                        <div class="bottom">
                            <p class="time"><?php echo $dc['adate']; ?></p>
                            <p class="hot"><?php echo $dc['clinum']; ?></p>
                        </div>
                    </div>
                </a>
                <?php else: ?>
                <a href="<?php echo url('index/index/ArticleDetail'); ?>?id=<?php echo $dc['id']; ?>" class="list">
<!--                    <img src="" class="left" alt="">-->
                    <div class="right">
                        <h1><?php echo $dc['title']; ?></h1>
                        <div class="bottom">
                            <p class="time"><?php echo $dc['adate']; ?></p>
                            <p class="hot"><?php echo $dc['clinum']; ?></p>
                        </div>
                    </div>
                </a>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <form action="<?php echo url('index/index/ArticleList'); ?>">
                <button class="loadMore">点击查看更多</button>

                <input type="hidden" name="hid" id="hid" value="<?php echo $tname; ?>" />
            </form>
        </div>
    </main>
    <footer>
        <a href="#">电话咨询</a>
        <a href="OnlionBuy.html">在线订购</a>
    </footer>
</div>
</body>
<script>
    $(".item12").find("ul").find("li").click(function () {
        var type = $(this).text();
        $("#hid").val(type);
        var index = $(this).index('.opt');
        $('.opt').removeClass('active').eq(index).addClass('active');
        $.post("<?php echo url('index/SelectTypeAll'); ?>",{type:type},function(data){
            console.log(data);
            $("#neirong").html(data);
        });
    })
</script>
</html>