<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:94:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/index/ArticleDetail.html";i:1560474384;s:90:"/www/wwwroot/fanyi.wangchuangcode.cn/public/../application/index/view/comm/navigation.html";i:1560493408;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>文章详情</title>
    <link rel="stylesheet" href="__STATIC__/qiantai/css/reset.css">
    <link rel="stylesheet" href="__STATIC__/qiantai/css/ArticleDetail.css">
    <script src="__STATIC__/qiantai/js/hotcss.js"></script>
    <script src="__STATIC__/qiantai/js/jquery-3.3.1.min.js"></script>
    <script src="__STATIC__/qiantai/js/common.js"></script>
</head>
<body>
<div class="container">
    <header>
        <div class="left">
            <a href="<?php echo url('index/index'); ?>" style="text-decoration: none"><h1>善顶级胶囊</h1></a>

            <p>www.shandingji.com</p>
        </div>
        <div class="right">
            <p></p>
            <p></p>
            <p></p>
        </div>
        <div class="close" style="display: none">
            <p></p>
            <p></p>
        </div>
    </header>
    <div class="option">
    <a href="<?php echo url('index/index'); ?>">首页</a>
    <a href="<?php echo url('index/ArticleList'); ?>?hid=最新文章">文章列表</a>
    <a href="http://pay.shandingji.com/pay/index.php/Customes/Index?pid=12">在线订购</a>
</div>

    <main>
        <h1><?php echo $result['title']; ?></h1>
        <h2>发布时间：<?php echo $result['adate']; ?></h2>
        <div class="content">
            <?php echo $result['content']; ?>
        </div>
    </main>
</div>
</body>
</html>