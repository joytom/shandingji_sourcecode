<?php
namespace app\index\controller;
use think\Controller;
use think\Db;

class Index extends Controller
{
    /**
    文章首页
     **/
    public function index()
    {
        //查询所有文章类型
        $data_type = Db::table('article')
            ->join('type','article.`tid`=type.tid')
            ->group('tname')
            ->order(["tname='最新文章'"=>'desc'])
            ->field('type.tid,type.tname')
            ->select();

        //获取默认的最新文章类型
        $tname=$data_type[0]['tname'];

        //查询第一个文章类型的所有文章
        $data_con = Db::table('article')
            ->limit(6)
            ->order('adate desc')
            ->select();
        $this->assign('tname',$tname);
        $this->assign('data_con',$data_con);
        $this->assign('data_type',$data_type);
        return view('index');
    }

    /**
    文章列表
     **/
    public function ArticleList(){

        $tname = input('hid');
        $datas = Db::table('type')
            ->where('tname',$tname)
            ->find();
        $tid = $datas['tid'];
        //查询该文章类型的所有文章
        if($tname=="最新文章"){
            $data_con = Db::table('article')
                ->order('adate desc')
                ->select();
        }else{
            $data_con = Db::table('article')
                ->where('tid',$tid)
                ->select();
        }
        $count=count($data_con);
        for($i=0;$i<$count;$i++)
        {
            $titles=$data_con[$i]['title'];
            $arr_title=mb_substr($titles,0,19);
            $data_con[$i]['titles']=$arr_title;

            $contents = $data_con[$i]['content'];
            $arr_content = strip_tags($contents);
            $arr_content=mb_substr($arr_content,0,20);
            $data_con[$i]['contents']=$arr_content."...";
        }
        $this->assign('tid',$tid);
        $this->assign('data_con',$data_con);
        return view('ArticleList');
    }

    /**
    文章详情页
     **/
    public function ArticleDetail(){
        $id = input('id');
        $result  = Db::table('article')
            ->where('id',$id)
            ->find();
        $upd_clinum = Db::table('article')
            ->where('id',$id)
            ->update(['clinum'=>$result['clinum']+1]);
        if($upd_clinum){
            $this->assign('result',$result);
            return view('ArticleDetail');
        }
    }

    /**
    文章搜索
     **/
    public function ArticleSearch(){
        $serach = input("serach");
        $tid = input("tid");
        if($tid==2){
            $data_con = Db::table('article')
                ->where('title','like',"%".$serach."%")
                ->select();
        }else{
            $data_con = Db::table('article')
                ->where('tid',$tid)
                ->where('title','like',"%".$serach."%")
                ->select();
        }
        $count=count($data_con);
        for($i=0;$i<$count;$i++)
        {
            $titles=$data_con[$i]['title'];
            $arr_title=mb_substr($titles,0,19);
            $data_con[$i]['titles']=$arr_title;

            $contents = $data_con[$i]['content'];
            $arr_content = strip_tags($contents);
            $arr_content=mb_substr($arr_content,0,20);
            $data_con[$i]['contents']=$arr_content."...";
        }
        $str = "";
        foreach($data_con as $key =>$val){
            $str.="
                <a href='ArticleDetail?id=".$val['id']."' class='list'>
                <div class='right' style='padding-left: 25px;'>
                    <h1>".$val['titles']."</h1> 
                    <h4>".$val['contents']."</h4>
                    <p class='time'>发布时间：".$val['adate']."</p>
</div></a>
            ";
        }
        echo $str;
    }

    /**
    在线支付
     **/
    public function OnlionBuy(){
        return view('OnlionBuy');
    }

    /**
    查询指定文章类型的所有文章
     **/
    public function SelectTypeAll(){
        $type = input('type');
        $data = Db::table('type')
            ->where('tname',$type)
            ->find();
        $tid = $data['tid'];

        if($type=="最新文章"){
            $result = Db::table('article')
                ->limit(6)
                ->order('adate desc')
                ->select();
        }else{
            $result = Db::table('article')
                ->where('tid',$tid)
                ->limit(6)
                ->select();
        }
        $str = "";
        foreach($result as $key=>$val){
            if($key<3){
                $str.="<a href='index/ArticleDetail?id=".$val['id']."' class='list'>
            <div class='right'>
                <h1 class='hotTop'><span>置顶</span>".$val['title']."</h1>
                <div class='bottom'>
                    <p class='time'>".$val['adate']."</p>
                    <p class='hot'>".$val['clinum']."</p>
                </div>
            </div>
            </a>";
            }else{
                $str.="<a href='index/ArticleDetail?id=".$val['id']."' class='list'>
            <div class='right'>
                <h1>".$val['title']."</h1>
                <div class='bottom'>
                    <p class='time'>".$val['adate']."</p>
                    <p class='hot'>".$val['clinum']."</p>
                </div>
            </div>
            </a>";
            }
        }
        echo $str;
    }
}