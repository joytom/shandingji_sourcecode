<?php
namespace app\admin\controller;
use think\Controller;
use think\Request;
use think\Db;

class Common extends Controller
{
    //检查是否登录
    public function _initialize()
    {
        if(!session('uname')){
            $this->error('请先登录！',url('/admin/login/index'));
        }
    }

}