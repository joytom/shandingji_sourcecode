<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Session;

class Login extends Controller{
    public function index(){
            if(null!=input('submit'))
            {
                $name=input('name');
                $pwd=input('pass');
                $user=Db::table('admin')
                    ->where('uname',$name)
                    ->where('upwd',$pwd)
                    ->find();
                if($user)
                {
                    Session::set('uname',$name);
                    $this->success('登陆成功','admin/Index/index');
                }
                else
                {
                    $this->error('用户名或密码错误','index');
                }
            }else{
                return view('login');
            }
    }
    function dieLogin()
    {
        Session(null);
        return view('login');
    }
}