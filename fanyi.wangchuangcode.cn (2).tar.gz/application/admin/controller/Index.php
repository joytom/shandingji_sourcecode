<?php
namespace app\admin\controller;
/**
 * Created by PhpStorm.
 * User: gao
 * Date: 2019/6/11
 * Time: 15:39
 */
use think\Controller;
use think\Db;

class Index extends Common
{

    //框架应用
    public function Index(){
        return view("index");
    }
    /**
     * 文章内容显示
     */
    public function AList(){

        $sou = request()->param();
        $name = input('tid') ? input('title') : ($sou['title'] = '');
        //判断是不是第一栏目
        $t_fid = input('t_fid') ? input('t_fid') : 0;
        $Z_tid = 2;

        if(isset($_POST['sousuo'])){
            $tid = input("tid");
            $title = input("title");
            $data = array();
            if(!empty($tid)){
                $data['a.tid'] = $tid;
            }
            if(!empty($title)){
                $data['title'] = ['like','%'.$title.'%'];
            }
            $arr=Db::table('article')
                ->alias('a')
                ->join('type t','a.tid=t.tid')
                ->field('a.*,t.tname')//查询指定字段
                ->where('a.tid','neq',$Z_tid)
                ->where($data)
                ->group('a.id')//分组
            ->paginate(5, false, ['query' => request()->param()]);//分页
        $page=$arr->render();
            $tid = Db::name('type')->select();
            return view("list",['arr'=>$arr,'tid'=>$tid,'page'=>$page,'title'=>$title]);
        }else{
            $arr=Db::table('article')
                ->alias('a')
                ->join('type t','a.tid=t.tid')
                ->field('a.*,t.tname')//查询指定字段
                ->where('a.tid','neq',$Z_tid)
                ->order("id desc")
                ->group('a.id')//分组
                ->paginate(5, false, ['query' => request()->param()]);//分页

        $page=$arr->render();
            $tid = Db::name('type') ->where('tid','neq',$Z_tid)->select();
            return view("list",['arr'=>$arr,'tid'=>$tid,'page'=>$page,'title'=>""]);
        }
    }

    /**
     * 修改文章内容
     */
    public function update(){

        $id=input('id');

        if(isset($_POST['sub'])){
            $tid = input("tid");
            $title = input("title");
            $name = input("ue");
            $adata = time();
            $xiugai=Db::name('article')
                ->where('id',$id)
                ->update(['title'=>$title,'tid'=>$tid,'content'=>$name,'adate'=>date('Y-m-d H:i:s',$adata)]);


            if($xiugai)
                $this->success('修改成功','admin/Index/Alist');
            else
                $this->error('修改失败','admin/Index/Alist');

        }else{
            $array=Db::table('article')
                ->alias('a')
                ->join('type t','a.tid=t.tid')
                ->where('id',$id)
                ->find();
            $type = Db::table('type')->select();
            return view("update",['arr'=>$array,'type'=>$type]);
        }

    }

    /**
     * 添加文章
     * @return \think\response\View
     */
    public function Add(){
        if(isset($_POST['sub'])){
            $tid = input("tid");
            $name = input("ue");
            $title = input("title");
            $adata = time();
//            echo date('Y-m-d H:i:s',(int)$adata);
            $tianjia=Db::table('article')
                ->insert(['tid'=>"$tid",'content'=>"$name",'adate'=>date('Y-m-d H:i:s',(int)$adata),'title'=>$title]);
            if($tianjia)
                $this->success('添加成功','admin/Index/Alist');
            else
                $this->error('添加失败','admin/Index/add');
        }
        $type=Db::query('select * from type where(tname!="最新文章")');
//        $type = Db::table('type')->where(tid)->select();
        return view("add",['type'=>$type]);
    }

    /**
     * 删除文章内容
     */
    public function delete(){
        $id=$_GET['id'];
        $rs=Db::table('article')->where('id',$id)->delete();
        if($rs)
        { $this->success('删除成功','admin/Index/Alist');}
        else
        {  $this->error('删除失败','admin/Index/Alist');}

    }
    /**
     * 添加文章分类
     */
    public function addType(){

        if(isset($_POST['sub'])){
            $tname = input("type");
            $tianjia=Db::table('type')
                ->insert(['tname'=>"$tname"]);
            if($tianjia)
                $this->success('添加成功','admin/Index/add');
            else
                $this->error('添加失败','admin/Index/addType');
        }
        return view("addType");
    }
    /**
     * 文章类型显示
     */
    public function typeContent(){
        $tid = Db::name('type')->select();
        return view("typeIndex",['arr'=>$tid]);
    }

    /**
     * 文章类型删除
     */
    public function type_delete(){
        $id=$_GET['id'];
        $rs=Db::table('type')->where('tid',$id)->delete();
        if($rs)
        { $this->success('删除成功','admin/Index/typeContent');}
        else
        {  $this->error('删除失败','admin/Index/typeContent');}
    }

    /**
     * 文章类型修改
     */
    public function type_update()
    {

        $id = input('tid');
        if (isset($_POST['sub'])) {
            $tname = input("tname");
            $xiugai = Db::name('type')
                ->where('tid', $id)
                ->update(['tname' => $tname]);
            if ($xiugai)
                $this->success('修改成功', 'admin/Index/typeContent');
            else
                $this->error('修改失败', 'admin/Index/typeContent');

        }else{
            $id = input('id');
            $array = Db::name('type')->where('tid',$id)->find();
            return view("type_update",['arr'=>$array]);
        }
    }
}