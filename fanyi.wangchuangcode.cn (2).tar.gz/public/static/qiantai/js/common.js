$(document).ready(function () {
    $('header .right').click(function () {
        $(this).hide();
        $('.close').show();
        $('.option').css('height','100%');
    })
    $('.close').click(function () {
        $(this).hide();
        $('header .right').show();
        $('.option').css('height','0%');
    })
})